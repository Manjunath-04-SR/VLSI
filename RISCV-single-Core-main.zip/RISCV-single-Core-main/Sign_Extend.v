// Sign Extend
// FIX: was only handling I-type — added S-type and B-type immediate formats
// ImmSrc: 2'b00 = I-type, 2'b01 = S-type, 2'b10 = B-type

module Sign_Extend(in, ImmSrc, imm_ext);

  input  [31:0] in;
  input  [1:0]  ImmSrc;
  output [31:0] imm_ext;

  assign imm_ext =
    // I-type: imm[11:0] = instr[31:20]
    (ImmSrc == 2'b00) ? {{20{in[31]}}, in[31:20]} :
    // S-type (SW): imm[11:5]=instr[31:25], imm[4:0]=instr[11:7]
    (ImmSrc == 2'b01) ? {{20{in[31]}}, in[31:25], in[11:7]} :
    // B-type (BEQ): imm[12]=instr[31], imm[10:5]=instr[30:25],
    //               imm[4:1]=instr[11:8], imm[11]=instr[7], imm[0]=0
    (ImmSrc == 2'b10) ? {{19{in[31]}}, in[31], in[7], in[30:25], in[11:8], 1'b0} :
    32'd0;

endmodule
