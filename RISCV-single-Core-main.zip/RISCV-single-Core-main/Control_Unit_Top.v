// Control Unit Top
// FIX: added zero input and PCSrc output (required by Single_cycle_Top)
// FIX: removed duplicate Branch assignment (was a multiple-driver conflict)
// FIX: fixed Main_Decoder port names (AluSrc->ALUSrc, Aluop->ALUOp)
// FIX: fixed ALU_Decoder port names and passed op5=Op[5] instead of full Op

`include "ALU_Decoder.v"
`include "Main_Decoder.v"

module Control_Unit_Top(Op, zero, RegWrite, ImmSrc, ALUSrc, MemWrite, ResultSrc, Branch, PCSrc, funct3, funct7, ALUControl);

    input [6:0] Op;
    input [2:0] funct3;
    input       funct7;  // bit 30 only (passed from RD_Instr[30])
    input       zero;    // ALU zero flag for branch evaluation

    output      RegWrite, ALUSrc, MemWrite, ResultSrc, Branch, PCSrc;
    output [1:0] ImmSrc;
    output [2:0] ALUControl;

    wire [1:0] ALUOp;

    Main_Decoder Main_Decoder(
        .op        (Op),
        .zero      (zero),
        .RegWrite  (RegWrite),
        .ImmSrc    (ImmSrc),
        .MemWrite  (MemWrite),
        .ResultSrc (ResultSrc),
        .ALUSrc    (ALUSrc),
        .PCSrc     (PCSrc),
        .ALUOp     (ALUOp)
    );

    ALU_Decoder ALU_Decoder(
        .ALUOp     (ALUOp),
        .funct3    (funct3),
        .funct7    (funct7),
        .op5       (Op[5]),   // bit 5 distinguishes R-type (1) from I-type (0)
        .ALUControl(ALUControl)
    );

    // Branch exposed for top-level wiring (same decode as inside Main_Decoder)
    assign Branch = (Op == 7'b1100011) ? 1'b1 : 1'b0;

endmodule
