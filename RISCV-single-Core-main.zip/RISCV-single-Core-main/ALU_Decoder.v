// ALU Decoder
// FIX: renamed module from alu_decoder -> ALU_Decoder (Verilog is case-sensitive)
// FIX: unified port names (AluOp->ALUOp, AluControl->ALUControl)
// FIX: added default case to avoid latch inference

module ALU_Decoder(ALUOp, op5, funct3, funct7, ALUControl);

  input       op5;    // bit 5 of opcode: 1 for R-type (0110011), 0 for I-type (0010011)
  input       funct7; // bit 30 of instruction (distinguishes ADD vs SUB)
  input [2:0] funct3;
  input [1:0] ALUOp;
  output [2:0] ALUControl;

  wire [1:0] Concatenation;
  assign Concatenation = {op5, funct7};

  assign ALUControl =
    (ALUOp == 2'b00)                                                         ? 3'b000 : // LW/SW/ADDI: ADD
    (ALUOp == 2'b01)                                                         ? 3'b001 : // BEQ: SUB (check zero)
    ((ALUOp == 2'b10) && (funct3 == 3'b010))                                 ? 3'b101 : // SLT
    ((ALUOp == 2'b10) && (funct3 == 3'b110))                                 ? 3'b011 : // OR
    ((ALUOp == 2'b10) && (funct3 == 3'b111))                                 ? 3'b010 : // AND
    ((ALUOp == 2'b10) && (funct3 == 3'b000) && (Concatenation == 2'b11))    ? 3'b001 : // SUB (R-type, funct7=1)
    ((ALUOp == 2'b10) && (funct3 == 3'b000))                                 ? 3'b000 : // ADD
    3'b000; // default: ADD

endmodule
