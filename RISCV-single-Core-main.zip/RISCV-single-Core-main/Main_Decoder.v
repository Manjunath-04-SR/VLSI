// Main Decoder
module Main_Decoder(op, zero, RegWrite, ResultSrc, MemWrite, ALUSrc, PCSrc, ImmSrc, ALUOp);

  input zero;
  input [6:0] op;
  output RegWrite, ResultSrc, MemWrite, ALUSrc, PCSrc;
  output [1:0] ImmSrc, ALUOp;

  wire branch;

  // RegWrite: load(0000011), R-type(0110011), I-type arith(0010011)
  assign RegWrite = (op==7'b0000011 | op==7'b0110011 | op==7'b0010011) ? 1'b1 : 1'b0;

  assign MemWrite = (op==7'b0100011) ? 1'b1 : 1'b0;

  assign ResultSrc = (op==7'b0000011) ? 1'b1 : 1'b0;

  // ALUSrc: load(0000011), store(0100011), I-type arith(0010011)
  assign ALUSrc = (op==7'b0000011 | op==7'b0100011 | op==7'b0010011) ? 1'b1 : 1'b0;

  // FIX: was (op =7'b1100011) — single = is assignment, not comparison
  assign branch = (op==7'b1100011) ? 1'b1 : 1'b0;

  // ImmSrc: I-type=00, S-type=01, B-type=10
  assign ImmSrc = (op==7'b0100011) ? 2'b01 : (op==7'b1100011) ? 2'b10 : 2'b00;

  // ALUOp: R-type=10, B-type=01, otherwise=00 (add for LW/SW/ADDI)
  assign ALUOp = (op==7'b0110011) ? 2'b10 : (op==7'b1100011) ? 2'b01 : 2'b00;

  assign PCSrc = zero & branch;

endmodule
