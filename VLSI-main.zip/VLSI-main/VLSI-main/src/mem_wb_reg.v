// ============================================================
// Module : mem_wb_reg.v
// Purpose: Pipeline register between MEM and WB stages
//
// MODIFIED FOR TAINT TRACKING:
//   Added taint_wb_in/out — carries the taint bit of the result
//   all the way to the WB stage, where it is written back into
//   the taint register file alongside the data.
//
//   Also used by the forwarding unit: when a MEM→EX forward
//   occurs, the taint_wb value is forwarded as the taint of
//   the forwarded data.
//
// Project: Hardware Dynamic Information Flow Tracking (DIFT)
//          on a 5-Stage RV32I Pipeline
// ============================================================
module mem_wb_reg (
    input  wire        clk,
    input  wire        rst,

    // ---- data inputs ----
    input  wire [31:0] pc_plus4_in,
    input  wire [31:0] alu_result_in,
    input  wire [31:0] mem_rdata_in,
    input  wire [4:0]  rd_in,

    // ---- control inputs ----
    input  wire        regwrite_in,
    input  wire [1:0]  wb_sel_in,

    // ---- taint input (NOVEL ADDITION) ----
    input  wire        taint_wb_in,   // taint bit of result entering WB stage

    // ---- data outputs ----
    output reg  [31:0] pc_plus4_out,
    output reg  [31:0] alu_result_out,
    output reg  [31:0] mem_rdata_out,
    output reg  [4:0]  rd_out,

    // ---- control outputs ----
    output reg         regwrite_out,
    output reg  [1:0]  wb_sel_out,

    // ---- taint output (NOVEL ADDITION) ----
    output reg         taint_wb_out   // taint written back to taint_regfile
);
    always @(posedge clk or posedge rst) begin
        if (rst) begin
            pc_plus4_out   <= 32'b0;
            alu_result_out <= 32'b0;
            mem_rdata_out  <= 32'b0;
            rd_out         <= 5'b0;
            regwrite_out   <= 1'b0;
            wb_sel_out     <= 2'b00;
            // taint reset
            taint_wb_out   <= 1'b0;
        end else begin
            pc_plus4_out   <= pc_plus4_in;
            alu_result_out <= alu_result_in;
            mem_rdata_out  <= mem_rdata_in;
            rd_out         <= rd_in;
            regwrite_out   <= regwrite_in;
            wb_sel_out     <= wb_sel_in;
            // carry taint to WB
            taint_wb_out   <= taint_wb_in;
        end
    end
endmodule
