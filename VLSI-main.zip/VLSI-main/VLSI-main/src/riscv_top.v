// ============================================================
// Module : riscv_top.v
// Purpose: Top-level integration of the 5-stage pipelined
//          RISC-V 32-bit (RV32I) processor with
//          HARDWARE TAINT TRACKING (DIFT)
//
// Pipeline stages:
//   IF  → IF/ID reg → ID → ID/EX reg → EX → EX/MEM reg
//       → MEM → MEM/WB reg → WB
//
// Original hazard handling:
//   • Data hazards    : forwarding unit (EX→EX, MEM→EX)
//   • Load-use stall  : hazard detection unit (1-cycle stall)
//   • Control hazards : branch/jump resolved in EX, flush 2 stages
//
// NOVEL ADDITION — Hardware Taint Tracking:
//   • taint_regfile    : 32 taint bits alongside register file data
//   • taint_unit       : propagates taint through ALU, detects violations
//   • csr_taint        : CSR bank for taint policy configuration
//   • Taint flows      : ID→ID/EX→EX→EX/MEM→MEM→MEM/WB→WB→regfile
//   • Forwarded taint  : same paths as data forwarding (EX→EX, MEM→EX)
//   • taint_exception  : raised when tainted data stored to protected region
//
// Project: Hardware Dynamic Information Flow Tracking (DIFT)
//          on a 5-Stage RV32I Pipeline
// ============================================================
module riscv_top (
    input  wire clk,
    input  wire rst,

    // ---- Taint CSR interface (driven by testbench / future decoder) ----
    input  wire        csr_we,          // CSR write enable
    input  wire [11:0] csr_addr,        // CSR address
    input  wire [31:0] csr_wdata,       // CSR write data

    // ---- Taint status outputs ----
    output wire        taint_exception, // 1 = tainted store to protected region
    output wire [31:0] taint_status,    // live taint state of all 32 registers
    output wire [31:0] csr_rdata        // CSR read data
);

// ========================================================
// ---- IF stage wires ----
// ========================================================
wire [31:0] pc_if;
wire [31:0] pc_plus4_if;
wire [31:0] instr_if;

// ========================================================
// ---- IF/ID register outputs ----
// ========================================================
wire [31:0] pc_id;
wire [31:0] instr_id;

// ========================================================
// ---- ID stage wires ----
// ========================================================
wire [4:0]  rs1_id    = instr_id[19:15];
wire [4:0]  rs2_id    = instr_id[24:20];
wire [4:0]  rd_id     = instr_id[11:7];
wire [2:0]  funct3_id = instr_id[14:12];
wire [6:0]  funct7_id = instr_id[31:25];

wire [31:0] rdata1_id, rdata2_id;
wire [31:0] imm_id;

// Control signals
wire        regwrite_id, memread_id, memwrite_id;
wire [1:0]  wb_sel_id;
wire        alusrc_id, branch_id, jal_id, jalr_id, auipc_id, lui_id;
wire [1:0]  aluop_id;

// Hazard
wire        stall;
wire        id_ex_flush;

// ---- TAINT: ID stage ----
wire        taint1_id, taint2_id;  // taint of rs1, rs2 from taint_regfile

// ========================================================
// ---- ID/EX register outputs ----
// ========================================================
wire [31:0] pc_ex, rdata1_ex, rdata2_ex, imm_ex;
wire [4:0]  rs1_ex, rs2_ex, rd_ex;
wire [2:0]  funct3_ex;
wire [6:0]  funct7_ex;
wire        regwrite_ex, memread_ex, memwrite_ex;
wire [1:0]  wb_sel_ex;
wire        alusrc_ex, branch_ex, jal_ex, jalr_ex, auipc_ex, lui_ex;
wire [1:0]  aluop_ex;

// ---- TAINT: ID/EX outputs ----
wire        taint1_ex, taint2_ex;  // taint bits arriving in EX stage

// ========================================================
// ---- EX stage wires ----
// ========================================================
wire [1:0]  forward_a, forward_b;
wire [31:0] rdata1_fwd, rdata2_fwd;
wire [31:0] alu_op_a, alu_op_b;
wire [3:0]  alu_ctrl_ex;
wire [31:0] alu_result_ex;
wire        alu_zero_ex;

wire        branch_taken, jump_taken, flush_pipe;
wire [31:0] pc_plus4_ex;
wire [31:0] jump_target;

// ---- TAINT: EX stage ----
wire        taint_a, taint_b;      // forwarded taint of ALU operands
wire        taint_result_ex;       // propagated taint for rd (from taint_unit)

// ========================================================
// ---- EX/MEM register outputs ----
// ========================================================
wire [31:0] pc_plus4_mem, alu_result_mem, rdata2_mem;
wire [4:0]  rd_mem;
wire [2:0]  funct3_mem;
wire        regwrite_mem, memread_mem, memwrite_mem;
wire [1:0]  wb_sel_mem;

// ---- TAINT: EX/MEM outputs ----
wire        taint_rd_mem;   // taint of ALU result (for MEM→EX forwarding)
wire        taint_rs2_mem;  // taint of store data (for MEM violation check)

// ========================================================
// ---- MEM stage wires ----
// ========================================================
wire [31:0] mem_rdata_mem;

// ---- TAINT: MEM stage ----
wire        taint_violation_mem;   // from taint_unit
wire        addr_in_prot_mem;      // debug

// ========================================================
// ---- MEM/WB register outputs ----
// ========================================================
wire [31:0] pc_plus4_wb, alu_result_wb, mem_rdata_wb;
wire [4:0]  rd_wb;
wire        regwrite_wb;
wire [1:0]  wb_sel_wb;

// ---- TAINT: MEM/WB outputs ----
wire        taint_wb_wb;   // taint arriving at WB stage

// ========================================================
// ---- WB stage ----
// ========================================================
wire [31:0] wb_data;
wire        wtaint;        // final taint bit written to taint_regfile

// ========================================================
// ---- CSR Taint policy wires ----
// ========================================================
wire        taint_en;
wire [31:0] taint_src_mask;
wire [31:0] prot_base, prot_bound;
wire        taint_init;


// ========================================================
// ========================  IF STAGE  ====================
// ========================================================

assign pc_plus4_if = pc_if + 32'd4;

wire [31:0] pc_next;
assign pc_next = flush_pipe ? jump_target :
                 stall      ? pc_if       :
                              pc_plus4_if;

pc_reg PC (
    .clk    (clk),
    .rst    (rst),
    .stall  (stall),
    .pc_next(pc_next),
    .pc     (pc_if)
);

instr_mem IMEM (
    .addr  (pc_if),
    .instr (instr_if)
);

if_id_reg IF_ID (
    .clk      (clk),
    .rst      (rst),
    .flush    (flush_pipe),
    .stall    (stall),
    .pc_in    (pc_if),
    .instr_in (instr_if),
    .pc_out   (pc_id),
    .instr_out(instr_id)
);


// ========================================================
// ========================  ID STAGE  ====================
// ========================================================

control_unit CTRL (
    .opcode  (instr_id[6:0]),
    .regwrite(regwrite_id),
    .memread (memread_id),
    .memwrite(memwrite_id),
    .wb_sel  (wb_sel_id),
    .alusrc  (alusrc_id),
    .branch  (branch_id),
    .jal     (jal_id),
    .jalr    (jalr_id),
    .auipc   (auipc_id),
    .lui     (lui_id),
    .aluop   (aluop_id)
);

// ---- TAINT-AWARE Register File ----
taint_regfile RF (
    .clk           (clk),
    .rst           (rst),
    .regwrite      (regwrite_wb),
    .rs1           (rs1_id),
    .rs2           (rs2_id),
    .rd            (rd_wb),
    .wdata         (wb_data),
    .rdata1        (rdata1_id),
    .rdata2        (rdata2_id),
    // taint ports
    .wtaint        (wtaint),
    .taint_src_mask(taint_src_mask),
    .taint_init    (taint_init),
    .taint1        (taint1_id),
    .taint2        (taint2_id),
    .taint_status  (taint_status)
);

imm_gen IGN (
    .instr(instr_id),
    .imm  (imm_id)
);

hazard_unit HDU (
    .id_ex_memread(memread_ex),
    .id_ex_rd     (rd_ex),
    .if_id_rs1    (rs1_id),
    .if_id_rs2    (rs2_id),
    .stall        (stall)
);

assign id_ex_flush = stall || flush_pipe;

// ---- ID/EX register (now carries taint bits) ----
id_ex_reg ID_EX (
    .clk         (clk),
    .rst         (rst),
    .flush       (id_ex_flush),
    .pc_in       (pc_id),
    .rdata1_in   (rdata1_id),
    .rdata2_in   (rdata2_id),
    .imm_in      (imm_id),
    .rs1_in      (rs1_id),
    .rs2_in      (rs2_id),
    .rd_in       (rd_id),
    .funct3_in   (funct3_id),
    .funct7_in   (funct7_id),
    .regwrite_in (regwrite_id),
    .memread_in  (memread_id),
    .memwrite_in (memwrite_id),
    .wb_sel_in   (wb_sel_id),
    .alusrc_in   (alusrc_id),
    .branch_in   (branch_id),
    .jal_in      (jal_id),
    .jalr_in     (jalr_id),
    .auipc_in    (auipc_id),
    .lui_in      (lui_id),
    .aluop_in    (aluop_id),
    // taint
    .taint1_in   (taint1_id),
    .taint2_in   (taint2_id),
    .pc_out      (pc_ex),
    .rdata1_out  (rdata1_ex),
    .rdata2_out  (rdata2_ex),
    .imm_out     (imm_ex),
    .rs1_out     (rs1_ex),
    .rs2_out     (rs2_ex),
    .rd_out      (rd_ex),
    .funct3_out  (funct3_ex),
    .funct7_out  (funct7_ex),
    .regwrite_out(regwrite_ex),
    .memread_out (memread_ex),
    .memwrite_out(memwrite_ex),
    .wb_sel_out  (wb_sel_ex),
    .alusrc_out  (alusrc_ex),
    .branch_out  (branch_ex),
    .jal_out     (jal_ex),
    .jalr_out    (jalr_ex),
    .auipc_out   (auipc_ex),
    .lui_out     (lui_ex),
    .aluop_out   (aluop_ex),
    // taint
    .taint1_out  (taint1_ex),
    .taint2_out  (taint2_ex)
);


// ========================================================
// ========================  EX STAGE  ====================
// ========================================================

assign wb_data = (wb_sel_wb == 2'b01) ? mem_rdata_wb  :
                 (wb_sel_wb == 2'b10) ? pc_plus4_wb   :
                                        alu_result_wb;

forward_unit FU (
    .ex_mem_regwrite(regwrite_mem),
    .ex_mem_rd      (rd_mem),
    .mem_wb_regwrite(regwrite_wb),
    .mem_wb_rd      (rd_wb),
    .id_ex_rs1      (rs1_ex),
    .id_ex_rs2      (rs2_ex),
    .forward_a      (forward_a),
    .forward_b      (forward_b)
);

// Data forwarding muxes
assign rdata1_fwd = (forward_a == 2'b10) ? alu_result_mem :
                    (forward_a == 2'b01) ? wb_data        :
                                           rdata1_ex;

assign rdata2_fwd = (forward_b == 2'b10) ? alu_result_mem :
                    (forward_b == 2'b01) ? wb_data        :
                                           rdata2_ex;

// ---- TAINT: Forwarded taint muxes (mirror data forwarding exactly) ----
// If data is forwarded, its taint must also be forwarded
assign taint_a = (forward_a == 2'b10) ? taint_rd_mem  :  // EX→EX forward
                 (forward_a == 2'b01) ? taint_wb_wb   :  // MEM→EX forward
                                        taint1_ex;       // no forward

assign taint_b = (forward_b == 2'b10) ? taint_rd_mem  :  // EX→EX forward
                 (forward_b == 2'b01) ? taint_wb_wb   :  // MEM→EX forward
                                        taint2_ex;       // no forward

assign alu_op_a = auipc_ex             ? pc_ex      :
                  lui_ex               ? 32'b0      :
                  (jal_ex || jalr_ex)  ? pc_ex      :
                                         rdata1_fwd;

assign alu_op_b = alusrc_ex ? imm_ex : rdata2_fwd;

alu_ctrl ALUCTL (
    .aluop   (aluop_ex),
    .funct3  (funct3_ex),
    .funct7  (funct7_ex),
    .alu_ctrl(alu_ctrl_ex)
);

alu ALU (
    .a       (alu_op_a),
    .b       (alu_op_b),
    .alu_ctrl(alu_ctrl_ex),
    .result  (alu_result_ex),
    .zero    (alu_zero_ex)
);

// ---- TAINT UNIT (EX stage portion: propagation) ----
// MEM stage portion (violation check) uses MEM-stage signals below
taint_unit TU (
    // EX: propagation
    .taint_a          (taint_a),
    .taint_b          (taint_b),
    // MEM: violation check (uses EX/MEM register outputs)
    .taint_en         (taint_en),
    .memwrite         (memwrite_mem),
    .taint_store_data (taint_rs2_mem),
    .store_addr       (alu_result_mem),
    .prot_base        (prot_base),
    .prot_bound       (prot_bound),
    // Outputs
    .taint_result     (taint_result_ex),
    .taint_violation  (taint_violation_mem),
    .addr_in_protected(addr_in_prot_mem)
);

// Branch condition comparator
reg branch_cond;
always @(*) begin
    case (funct3_ex)
        3'b000: branch_cond = (rdata1_fwd == rdata2_fwd);
        3'b001: branch_cond = (rdata1_fwd != rdata2_fwd);
        3'b100: branch_cond = ($signed(rdata1_fwd) <  $signed(rdata2_fwd));
        3'b101: branch_cond = ($signed(rdata1_fwd) >= $signed(rdata2_fwd));
        3'b110: branch_cond = (rdata1_fwd <  rdata2_fwd);
        3'b111: branch_cond = (rdata1_fwd >= rdata2_fwd);
        default: branch_cond = 1'b0;
    endcase
end

assign branch_taken = branch_ex && branch_cond;
assign jump_taken   = jal_ex   || jalr_ex;
assign flush_pipe   = branch_taken || jump_taken;

wire [31:0] jal_target    = pc_ex + imm_ex;
wire [31:0] jalr_target   = (rdata1_fwd + imm_ex) & 32'hFFFF_FFFE;
wire [31:0] branch_target = pc_ex + imm_ex;

assign jump_target = jalr_ex ? jalr_target :
                     jal_ex  ? jal_target  :
                               branch_target;

assign pc_plus4_ex = pc_ex + 32'd4;

// ---- EX/MEM register (now carries taint bits) ----
ex_mem_reg EX_MEM (
    .clk            (clk),
    .rst            (rst),
    .pc_plus4_in    (pc_plus4_ex),
    .alu_result_in  (alu_result_ex),
    .rdata2_in      (rdata2_fwd),
    .rd_in          (rd_ex),
    .funct3_in      (funct3_ex),
    .regwrite_in    (regwrite_ex),
    .memread_in     (memread_ex),
    .memwrite_in    (memwrite_ex),
    .wb_sel_in      (wb_sel_ex),
    // taint
    .taint_rd_in    (taint_result_ex),  // propagated taint of ALU result
    .taint_rs2_in   (taint_b),          // taint of store data (rs2 after forwarding)
    .pc_plus4_out   (pc_plus4_mem),
    .alu_result_out (alu_result_mem),
    .rdata2_out     (rdata2_mem),
    .rd_out         (rd_mem),
    .funct3_out     (funct3_mem),
    .regwrite_out   (regwrite_mem),
    .memread_out    (memread_mem),
    .memwrite_out   (memwrite_mem),
    .wb_sel_out     (wb_sel_mem),
    // taint
    .taint_rd_out   (taint_rd_mem),
    .taint_rs2_out  (taint_rs2_mem)
);


// ========================================================
// ======================== MEM STAGE =====================
// ========================================================

data_mem DMEM (
    .clk     (clk),
    .memread (memread_mem),
    .memwrite(memwrite_mem),
    .funct3  (funct3_mem),
    .addr    (alu_result_mem),
    .wdata   (rdata2_mem),
    .rdata   (mem_rdata_mem)
);

// ---- TAINT: MEM/WB register ----
// taint_wb_in = taint of ALU result (which is also address taint for loads)
// If address was tainted → loaded value is tainted (pointer taint propagation)
mem_wb_reg MEM_WB (
    .clk            (clk),
    .rst            (rst),
    .pc_plus4_in    (pc_plus4_mem),
    .alu_result_in  (alu_result_mem),
    .mem_rdata_in   (mem_rdata_mem),
    .rd_in          (rd_mem),
    .regwrite_in    (regwrite_mem),
    .wb_sel_in      (wb_sel_mem),
    // taint
    .taint_wb_in    (taint_rd_mem),     // ALU result taint propagates to WB
    .pc_plus4_out   (pc_plus4_wb),
    .alu_result_out (alu_result_wb),
    .mem_rdata_out  (mem_rdata_wb),
    .rd_out         (rd_wb),
    .regwrite_out   (regwrite_wb),
    .wb_sel_out     (wb_sel_wb),
    // taint
    .taint_wb_out   (taint_wb_wb)
);


// ========================================================
// ========================  WB STAGE  ====================
// ========================================================

// WB taint mux: PC+4 (JAL return addr) is NOT tainted; ALU/Load result carries taint
// Rule: control-flow addresses are trusted; data derived from tainted sources is not
assign wtaint = (wb_sel_wb == 2'b10) ? 1'b0       :  // PC+4: always trusted
                                        taint_wb_wb;  // ALU result or load: carry taint


// ========================================================
// ======================== TAINT CSR =====================
// ========================================================

csr_taint CSR (
    .clk            (clk),
    .rst            (rst),
    .csr_we         (csr_we),
    .csr_addr       (csr_addr),
    .csr_wdata      (csr_wdata),
    .taint_status   (taint_status),
    .taint_violation(taint_violation_mem),
    .taint_en       (taint_en),
    .taint_src_mask (taint_src_mask),
    .prot_base      (prot_base),
    .prot_bound     (prot_bound),
    .taint_init     (taint_init),
    .excpt_count    (),              // can be wired to output if needed
    .csr_rdata      (csr_rdata)
);

// Expose taint exception to top-level (e.g. to halt pipeline or signal interrupt)
assign taint_exception = taint_violation_mem;

endmodule
