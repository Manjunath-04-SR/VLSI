// ============================================================
// Module : taint_regfile.v
// Purpose: 32 x 32-bit Register File with 1-bit Hardware Taint Tags
//
// NOVEL CONTRIBUTION:
//   Each register xi carries a 1-bit taint tag alongside its data.
//   Taint tag propagates through the pipeline — if any source
//   register is tainted, the computed result is also tainted.
//   Tainted stores to protected memory regions raise a hardware
//   exception without any software overhead.
//
// Taint Sources:
//   - Set via taint_src_mask (CSR 0x801): bit[i]=1 means xi is tainted
//   - taint_init pulse applies the mask to taint_regs
//
// Taint Write-back:
//   - wtaint written to taint_regs[rd] on every regfile write
//
// Project: Hardware Dynamic Information Flow Tracking (DIFT)
//          on a 5-Stage RV32I Pipeline
// ============================================================
module taint_regfile (
    input  wire        clk,
    input  wire        rst,

    // ---- Data interface (same as original regfile) ----
    input  wire        regwrite,       // write enable from WB stage
    input  wire [4:0]  rs1,            // source register 1 address
    input  wire [4:0]  rs2,            // source register 2 address
    input  wire [4:0]  rd,             // destination register address
    input  wire [31:0] wdata,          // data to write
    output wire [31:0] rdata1,         // read data 1
    output wire [31:0] rdata2,         // read data 2

    // ---- Taint interface (novel addition) ----
    input  wire        wtaint,         // taint bit to write to rd
    input  wire [31:0] taint_src_mask, // CSR: bitmask of initially-tainted registers
    input  wire        taint_init,     // pulse high to load taint_src_mask into taint_regs
    output wire        taint1,         // taint of rs1 (read combinationally)
    output wire        taint2,         // taint of rs2 (read combinationally)
    output wire [31:0] taint_status    // full taint state of all 32 registers (for CSR read)
);

    reg [31:0] regs  [1:31];   // x1..x31 data (x0 = 0, hardwired)
    reg [31:0] taints;         // taints[i] = taint bit for register xi

    integer idx;
    initial begin
        for (idx = 1; idx < 32; idx = idx + 1)
            regs[idx] = 32'b0;
        taints = 32'b0;
    end

    // -------------------------------------------------------
    // Synchronous write — data and taint written together
    // Priority: taint_init overrides normal write
    // -------------------------------------------------------
    always @(posedge clk or posedge rst) begin
        if (rst) begin
            taints <= 32'b0;
        end else if (taint_init) begin
            // Load taint source mask from CSR policy
            taints <= taint_src_mask;
        end else if (regwrite && rd != 5'b0) begin
            regs[rd]      <= wdata;
            taints[rd]    <= wtaint;
            taints[0]     <= 1'b0; // x0 never tainted
        end
    end

    // -------------------------------------------------------
    // Asynchronous read with write-through (WB→ID same cycle)
    // -------------------------------------------------------
    assign rdata1 = (rs1 == 5'b0)                         ? 32'b0 :
                    (regwrite && rd == rs1 && rd != 5'b0) ? wdata  :
                    regs[rs1];

    assign rdata2 = (rs2 == 5'b0)                         ? 32'b0 :
                    (regwrite && rd == rs2 && rd != 5'b0) ? wdata  :
                    regs[rs2];

    // -------------------------------------------------------
    // Taint read — also with write-through for same-cycle hazard
    // -------------------------------------------------------
    assign taint1 = (rs1 == 5'b0)                         ? 1'b0   :
                    (regwrite && rd == rs1 && rd != 5'b0) ? wtaint :
                    taints[rs1];

    assign taint2 = (rs2 == 5'b0)                         ? 1'b0   :
                    (regwrite && rd == rs2 && rd != 5'b0) ? wtaint :
                    taints[rs2];

    // Expose full taint register state for CSR_TAINT_STATUS read
    assign taint_status = {taints[31:1], 1'b0}; // x0 always untainted

endmodule
