// ============================================================
// Module : taint_unit.v
// Purpose: Hardware Taint Propagation Engine + Policy Enforcer
//
// NOVEL CONTRIBUTION:
//   This unit sits in the EX and MEM stages and performs two roles:
//
//   1. PROPAGATION (EX stage):
//      taint_result = taint_a OR taint_b
//      If either operand is tainted, the result register is tainted.
//      This models the information flow rule:
//        "secret data + any operation = still secret"
//
//   2. VIOLATION DETECTION (MEM stage):
//      Raises taint_exception when ALL of:
//        a) Taint tracking is enabled (taint_en)
//        b) It is a store instruction (memwrite)
//        c) The data being stored is tainted (taint_store_data)
//        d) The store address falls in the protected region
//           prot_base <= store_addr < prot_bound
//
//   Example attack this catches:
//      x5 = user_input()  → x5 is tainted (attacker-controlled)
//      sw x5, 0(x2)       → if x2 points to return address / protected
//                            region → EXCEPTION raised before write!
//
// Project: Hardware Dynamic Information Flow Tracking (DIFT)
//          on a 5-Stage RV32I Pipeline
// ============================================================
module taint_unit (
    // ---- EX stage: taint propagation inputs ----
    input  wire        taint_a,           // taint of ALU operand A (after forwarding)
    input  wire        taint_b,           // taint of ALU operand B (after forwarding)

    // ---- MEM stage: violation detection inputs ----
    input  wire        taint_en,          // global taint enable (from CSR)
    input  wire        memwrite,          // store instruction in MEM stage
    input  wire        taint_store_data,  // taint of data being stored (rs2 taint)
    input  wire [31:0] store_addr,        // effective byte address (ALU result)
    input  wire [31:0] prot_base,         // protected region base  (from CSR)
    input  wire [31:0] prot_bound,        // protected region bound (exclusive, from CSR)

    // ---- Outputs ----
    output wire        taint_result,      // propagated taint → written to rd via WB
    output wire        taint_violation,   // 1 = tainted store to protected region
    output wire        addr_in_protected  // debug: address fell in protected zone
);

    // ----------------------------------------------------------
    // Taint Propagation Rule
    // Any computation involving a tainted value produces a tainted result
    // ----------------------------------------------------------
    assign taint_result = taint_a | taint_b;

    // ----------------------------------------------------------
    // Protected Region Check
    // ----------------------------------------------------------
    assign addr_in_protected = (store_addr >= prot_base) &&
                               (store_addr <  prot_bound);

    // ----------------------------------------------------------
    // Taint Violation (raises hardware exception)
    // ----------------------------------------------------------
    assign taint_violation = taint_en        &&
                             memwrite        &&
                             taint_store_data &&
                             addr_in_protected;

endmodule
