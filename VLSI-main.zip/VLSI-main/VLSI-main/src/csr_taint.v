// ============================================================
// Module : csr_taint.v
// Purpose: Custom CSR Register Bank for Hardware Taint Tracking
//
// CSR Address Map (custom, in user-defined range 0x800-0x8FF):
//
//   0x800  TAINT_EN        [0:0]  RW  Global taint enable
//                                      1 = tracking active, violations raise exception
//                                      0 = tracking disabled (passthrough)
//
//   0x801  TAINT_SRC_MASK  [31:0] RW  Taint source register mask
//                                      bit[i]=1 → register xi starts as tainted
//                                      Write then pulse taint_init to apply
//
//   0x802  TAINT_STATUS    [31:0] RO  Current live taint of all 32 registers
//                                      Reflects real-time state of taint_regfile
//
//   0x803  TAINT_PROT_BASE [31:0] RW  Protected memory region base address
//   0x804  TAINT_PROT_BOUND[31:0] RW  Protected memory region bound (exclusive)
//
//   0x805  TAINT_EXCPT_CNT [31:0] RO  Count of taint violations detected so far
//
// Usage from testbench / software:
//   Drive csr_we=1, csr_addr=0x801, csr_wdata=32'h00000004 (taint x2)
//   Drive taint_init=1 for 1 cycle to load mask into register file
//   Drive csr_we=1, csr_addr=0x803, csr_wdata=base_address
//   Drive csr_we=1, csr_addr=0x804, csr_wdata=bound_address
//   Drive csr_we=1, csr_addr=0x800, csr_wdata=32'h1 to enable
//
// Project: Hardware Dynamic Information Flow Tracking (DIFT)
//          on a 5-Stage RV32I Pipeline
// ============================================================
module csr_taint (
    input  wire        clk,
    input  wire        rst,

    // ---- CSR write interface ----
    // (Driven by testbench or future CSR instruction decoder)
    input  wire        csr_we,          // write enable
    input  wire [11:0] csr_addr,        // CSR register address
    input  wire [31:0] csr_wdata,       // write data

    // ---- Status inputs ----
    input  wire [31:0] taint_status,    // live taint state from taint_regfile
    input  wire        taint_violation, // pulse from taint_unit on violation

    // ---- Policy outputs (to rest of pipeline) ----
    output reg         taint_en,        // global taint enable
    output reg  [31:0] taint_src_mask,  // register taint source mask
    output reg  [31:0] prot_base,       // protected region base
    output reg  [31:0] prot_bound,      // protected region bound

    // ---- Init pulse (to taint_regfile) ----
    output reg         taint_init,      // 1-cycle pulse to apply taint_src_mask

    // ---- Diagnostic outputs ----
    output reg  [31:0] excpt_count,     // cumulative violation counter
    output reg  [31:0] csr_rdata        // CSR read data
);

    // CSR address constants
    localparam CSR_TAINT_EN     = 12'h800;
    localparam CSR_TAINT_SRC    = 12'h801;
    localparam CSR_TAINT_STATUS = 12'h802;
    localparam CSR_PROT_BASE    = 12'h803;
    localparam CSR_PROT_BOUND   = 12'h804;
    localparam CSR_EXCPT_CNT    = 12'h805;

    // -------------------------------------------------------
    // Synchronous: CSR writes + violation counter
    // -------------------------------------------------------
    always @(posedge clk or posedge rst) begin
        if (rst) begin
            taint_en        <= 1'b0;
            taint_src_mask  <= 32'b0;
            prot_base       <= 32'h0000_0100; // default protected: 0x100-0x1FF
            prot_bound      <= 32'h0000_0200;
            excpt_count     <= 32'b0;
            taint_init      <= 1'b0;
        end else begin
            taint_init <= 1'b0; // default: no init pulse

            // Count violations
            if (taint_violation)
                excpt_count <= excpt_count + 1;

            // Process CSR writes
            if (csr_we) begin
                case (csr_addr)
                    CSR_TAINT_EN:  taint_en       <= csr_wdata[0];
                    CSR_TAINT_SRC: begin
                                   taint_src_mask <= csr_wdata;
                                   taint_init     <= 1'b1; // auto-apply mask on write
                                   end
                    CSR_PROT_BASE: prot_base       <= csr_wdata;
                    CSR_PROT_BOUND:prot_bound       <= csr_wdata;
                    default: ;
                endcase
            end
        end
    end

    // -------------------------------------------------------
    // Combinational CSR read
    // -------------------------------------------------------
    always @(*) begin
        case (csr_addr)
            CSR_TAINT_EN:     csr_rdata = {31'b0, taint_en};
            CSR_TAINT_SRC:    csr_rdata = taint_src_mask;
            CSR_TAINT_STATUS: csr_rdata = taint_status;
            CSR_PROT_BASE:    csr_rdata = prot_base;
            CSR_PROT_BOUND:   csr_rdata = prot_bound;
            CSR_EXCPT_CNT:    csr_rdata = excpt_count;
            default:          csr_rdata = 32'b0;
        endcase
    end

endmodule
