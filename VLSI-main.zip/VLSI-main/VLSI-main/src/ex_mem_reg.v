// ============================================================
// Module : ex_mem_reg.v
// Purpose: Pipeline register between EX and MEM stages
//
// MODIFIED FOR TAINT TRACKING:
//   Added taint_rd_in/out  — taint of the ALU result (destination register taint)
//   Added taint_rs2_in/out — taint of the store data (rs2 value, needed for
//                             the MEM-stage violation check: is the data
//                             being stored to protected memory tainted?)
//
// Project: Hardware Dynamic Information Flow Tracking (DIFT)
//          on a 5-Stage RV32I Pipeline
// ============================================================
module ex_mem_reg (
    input  wire        clk,
    input  wire        rst,

    // ---- data inputs ----
    input  wire [31:0] pc_plus4_in,
    input  wire [31:0] alu_result_in,
    input  wire [31:0] rdata2_in,
    input  wire [4:0]  rd_in,
    input  wire [2:0]  funct3_in,

    // ---- control inputs ----
    input  wire        regwrite_in,
    input  wire        memread_in,
    input  wire        memwrite_in,
    input  wire [1:0]  wb_sel_in,

    // ---- taint inputs (NOVEL ADDITION) ----
    input  wire        taint_rd_in,   // propagated taint for destination register
    input  wire        taint_rs2_in,  // taint of rs2 (store data)

    // ---- data outputs ----
    output reg  [31:0] pc_plus4_out,
    output reg  [31:0] alu_result_out,
    output reg  [31:0] rdata2_out,
    output reg  [4:0]  rd_out,
    output reg  [2:0]  funct3_out,

    // ---- control outputs ----
    output reg         regwrite_out,
    output reg         memread_out,
    output reg         memwrite_out,
    output reg  [1:0]  wb_sel_out,

    // ---- taint outputs (NOVEL ADDITION) ----
    output reg         taint_rd_out,  // taint for rd, used in MEM→EX forwarding
    output reg         taint_rs2_out  // taint of store data, used in MEM violation check
);
    always @(posedge clk or posedge rst) begin
        if (rst) begin
            pc_plus4_out   <= 32'b0;
            alu_result_out <= 32'b0;
            rdata2_out     <= 32'b0;
            rd_out         <= 5'b0;
            funct3_out     <= 3'b0;
            regwrite_out   <= 1'b0;
            memread_out    <= 1'b0;
            memwrite_out   <= 1'b0;
            wb_sel_out     <= 2'b00;
            // taint reset
            taint_rd_out   <= 1'b0;
            taint_rs2_out  <= 1'b0;
        end else begin
            pc_plus4_out   <= pc_plus4_in;
            alu_result_out <= alu_result_in;
            rdata2_out     <= rdata2_in;
            rd_out         <= rd_in;
            funct3_out     <= funct3_in;
            regwrite_out   <= regwrite_in;
            memread_out    <= memread_in;
            memwrite_out   <= memwrite_in;
            wb_sel_out     <= wb_sel_in;
            // carry taint bits forward
            taint_rd_out   <= taint_rd_in;
            taint_rs2_out  <= taint_rs2_in;
        end
    end
endmodule
