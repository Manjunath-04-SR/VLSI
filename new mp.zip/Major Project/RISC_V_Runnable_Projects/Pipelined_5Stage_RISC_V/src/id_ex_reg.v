// Module: id_ex_reg.v — ID/EX pipeline register
module id_ex_reg (
    input  wire        clk, rst, flush,
    input  wire [31:0] pc_in, rdata1_in, rdata2_in, imm_in,
    input  wire [4:0]  rs1_in, rs2_in, rd_in,
    input  wire [2:0]  funct3_in,
    input  wire [6:0]  funct7_in,
    input  wire        regwrite_in, memread_in, memwrite_in,
    input  wire [1:0]  wb_sel_in,
    input  wire        alusrc_in, branch_in, jal_in, jalr_in, auipc_in, lui_in,
    input  wire [1:0]  aluop_in,
    output reg  [31:0] pc_out, rdata1_out, rdata2_out, imm_out,
    output reg  [4:0]  rs1_out, rs2_out, rd_out,
    output reg  [2:0]  funct3_out,
    output reg  [6:0]  funct7_out,
    output reg         regwrite_out, memread_out, memwrite_out,
    output reg  [1:0]  wb_sel_out,
    output reg         alusrc_out, branch_out, jal_out, jalr_out, auipc_out, lui_out,
    output reg  [1:0]  aluop_out
);
    always @(posedge clk or posedge rst) begin
        if (rst || flush) begin
            pc_out<=0; rdata1_out<=0; rdata2_out<=0; imm_out<=0;
            rs1_out<=0; rs2_out<=0; rd_out<=0; funct3_out<=0; funct7_out<=0;
            regwrite_out<=0; memread_out<=0; memwrite_out<=0; wb_sel_out<=0;
            alusrc_out<=0; branch_out<=0; jal_out<=0; jalr_out<=0;
            auipc_out<=0; lui_out<=0; aluop_out<=0;
        end else begin
            pc_out<=pc_in; rdata1_out<=rdata1_in; rdata2_out<=rdata2_in; imm_out<=imm_in;
            rs1_out<=rs1_in; rs2_out<=rs2_in; rd_out<=rd_in;
            funct3_out<=funct3_in; funct7_out<=funct7_in;
            regwrite_out<=regwrite_in; memread_out<=memread_in; memwrite_out<=memwrite_in;
            wb_sel_out<=wb_sel_in; alusrc_out<=alusrc_in; branch_out<=branch_in;
            jal_out<=jal_in; jalr_out<=jalr_in; auipc_out<=auipc_in;
            lui_out<=lui_in; aluop_out<=aluop_in;
        end
    end
endmodule
