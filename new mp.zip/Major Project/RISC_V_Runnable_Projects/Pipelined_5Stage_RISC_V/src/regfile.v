// Module: regfile.v — 32x32-bit register file
module regfile (
    input  wire        clk,
    input  wire        regwrite,
    input  wire [4:0]  rs1,
    input  wire [4:0]  rs2,
    input  wire [4:0]  rd,
    input  wire [31:0] wdata,
    output wire [31:0] rdata1,
    output wire [31:0] rdata2
);
    reg [31:0] regs [1:31];
    integer i;
    initial begin
        for (i = 1; i < 32; i = i + 1)
            regs[i] = 32'b0;
    end
    always @(posedge clk) begin
        if (regwrite && rd != 5'b0)
            regs[rd] <= wdata;
    end
    assign rdata1 = (rs1 == 5'b0)                         ? 32'b0 :
                    (regwrite && rd == rs1 && rd != 5'b0)  ? wdata :
                    regs[rs1];
    assign rdata2 = (rs2 == 5'b0)                         ? 32'b0 :
                    (regwrite && rd == rs2 && rd != 5'b0)  ? wdata :
                    regs[rs2];
endmodule
