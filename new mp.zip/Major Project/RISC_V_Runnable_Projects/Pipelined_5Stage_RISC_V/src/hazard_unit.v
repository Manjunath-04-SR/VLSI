// Module: hazard_unit.v — load-use hazard detection
module hazard_unit (
    input  wire        id_ex_memread,
    input  wire [4:0]  id_ex_rd,
    input  wire [4:0]  if_id_rs1,
    input  wire [4:0]  if_id_rs2,
    output wire        stall
);
    assign stall = id_ex_memread &&
                   ((id_ex_rd == if_id_rs1) || (id_ex_rd == if_id_rs2)) &&
                   (id_ex_rd != 5'b0);
endmodule
