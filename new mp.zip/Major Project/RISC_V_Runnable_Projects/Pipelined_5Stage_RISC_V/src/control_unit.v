// Module: control_unit.v
module control_unit (
    input  wire [6:0] opcode,
    output reg        regwrite,
    output reg        memread,
    output reg        memwrite,
    output reg  [1:0] wb_sel,
    output reg        alusrc,
    output reg        branch,
    output reg        jal,
    output reg        jalr,
    output reg        auipc,
    output reg        lui,
    output reg  [1:0] aluop
);
    localparam OP_R     = 7'b011_0011;
    localparam OP_I_ALU = 7'b001_0011;
    localparam OP_LOAD  = 7'b000_0011;
    localparam OP_STORE = 7'b010_0011;
    localparam OP_BRANCH= 7'b110_0011;
    localparam OP_JAL   = 7'b110_1111;
    localparam OP_JALR  = 7'b110_0111;
    localparam OP_LUI   = 7'b011_0111;
    localparam OP_AUIPC = 7'b001_0111;

    always @(*) begin
        regwrite = 1'b0; memread  = 1'b0; memwrite = 1'b0;
        wb_sel   = 2'b00; alusrc  = 1'b0; branch   = 1'b0;
        jal      = 1'b0;  jalr    = 1'b0; auipc    = 1'b0;
        lui      = 1'b0;  aluop   = 2'b00;
        case (opcode)
            OP_R:      begin regwrite=1; aluop=2'b10; end
            OP_I_ALU:  begin regwrite=1; alusrc=1; aluop=2'b10; end
            OP_LOAD:   begin regwrite=1; memread=1; alusrc=1; wb_sel=2'b01; end
            OP_STORE:  begin memwrite=1; alusrc=1; end
            OP_BRANCH: begin branch=1; aluop=2'b01; end
            OP_JAL:    begin regwrite=1; jal=1; wb_sel=2'b10; end
            OP_JALR:   begin regwrite=1; jalr=1; alusrc=1; wb_sel=2'b10; end
            OP_LUI:    begin regwrite=1; lui=1; alusrc=1; aluop=2'b11; end
            OP_AUIPC:  begin regwrite=1; auipc=1; alusrc=1; end
            default:   begin end
        endcase
    end
endmodule
