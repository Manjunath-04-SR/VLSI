// Module: mem_wb_reg.v — MEM/WB pipeline register
module mem_wb_reg (
    input  wire        clk, rst,
    input  wire [31:0] pc_plus4_in, alu_result_in, mem_rdata_in,
    input  wire [4:0]  rd_in,
    input  wire        regwrite_in,
    input  wire [1:0]  wb_sel_in,
    output reg  [31:0] pc_plus4_out, alu_result_out, mem_rdata_out,
    output reg  [4:0]  rd_out,
    output reg         regwrite_out,
    output reg  [1:0]  wb_sel_out
);
    always @(posedge clk or posedge rst) begin
        if (rst) begin
            pc_plus4_out<=0; alu_result_out<=0; mem_rdata_out<=0;
            rd_out<=0; regwrite_out<=0; wb_sel_out<=0;
        end else begin
            pc_plus4_out<=pc_plus4_in; alu_result_out<=alu_result_in;
            mem_rdata_out<=mem_rdata_in; rd_out<=rd_in;
            regwrite_out<=regwrite_in; wb_sel_out<=wb_sel_in;
        end
    end
endmodule
