// Module: data_mem.v — 1KB byte-addressable data memory
module data_mem (
    input  wire        clk, memread, memwrite,
    input  wire [2:0]  funct3,
    input  wire [31:0] addr, wdata,
    output reg  [31:0] rdata
);
    reg [7:0] mem [0:1023];
    integer i;
    initial begin
        for (i = 0; i < 1024; i = i + 1)
            mem[i] = 8'b0;
    end
    always @(posedge clk) begin
        if (memwrite) begin
            case (funct3)
                3'b000: mem[addr] <= wdata[7:0];
                3'b001: {mem[addr+1], mem[addr]} <= wdata[15:0];
                3'b010: {mem[addr+3], mem[addr+2], mem[addr+1], mem[addr]} <= wdata[31:0];
                default: ;
            endcase
        end
    end
    always @(*) begin
        if (memread) begin
            case (funct3)
                3'b000: rdata = {{24{mem[addr][7]}}, mem[addr]};
                3'b001: rdata = {{16{mem[addr+1][7]}}, mem[addr+1], mem[addr]};
                3'b010: rdata = {mem[addr+3], mem[addr+2], mem[addr+1], mem[addr]};
                3'b100: rdata = {24'b0, mem[addr]};
                3'b101: rdata = {16'b0, mem[addr+1], mem[addr]};
                default: rdata = 32'b0;
            endcase
        end else
            rdata = 32'b0;
    end
endmodule
