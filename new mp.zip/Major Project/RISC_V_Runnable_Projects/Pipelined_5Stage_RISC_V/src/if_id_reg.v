// Module: if_id_reg.v — IF/ID pipeline register
module if_id_reg (
    input  wire        clk,
    input  wire        rst,
    input  wire        flush,
    input  wire        stall,
    input  wire [31:0] pc_in,
    input  wire [31:0] instr_in,
    output reg  [31:0] pc_out,
    output reg  [31:0] instr_out
);
    always @(posedge clk or posedge rst) begin
        if (rst || flush) begin
            pc_out    <= 32'b0;
            instr_out <= 32'h0000_0013;
        end else if (!stall) begin
            pc_out    <= pc_in;
            instr_out <= instr_in;
        end
    end
endmodule
