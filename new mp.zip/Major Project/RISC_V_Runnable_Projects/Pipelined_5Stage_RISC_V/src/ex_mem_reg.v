// Module: ex_mem_reg.v — EX/MEM pipeline register
module ex_mem_reg (
    input  wire        clk, rst,
    input  wire [31:0] pc_plus4_in, alu_result_in, rdata2_in,
    input  wire [4:0]  rd_in,
    input  wire [2:0]  funct3_in,
    input  wire        regwrite_in, memread_in, memwrite_in,
    input  wire [1:0]  wb_sel_in,
    output reg  [31:0] pc_plus4_out, alu_result_out, rdata2_out,
    output reg  [4:0]  rd_out,
    output reg  [2:0]  funct3_out,
    output reg         regwrite_out, memread_out, memwrite_out,
    output reg  [1:0]  wb_sel_out
);
    always @(posedge clk or posedge rst) begin
        if (rst) begin
            pc_plus4_out<=0; alu_result_out<=0; rdata2_out<=0;
            rd_out<=0; funct3_out<=0;
            regwrite_out<=0; memread_out<=0; memwrite_out<=0; wb_sel_out<=0;
        end else begin
            pc_plus4_out<=pc_plus4_in; alu_result_out<=alu_result_in; rdata2_out<=rdata2_in;
            rd_out<=rd_in; funct3_out<=funct3_in;
            regwrite_out<=regwrite_in; memread_out<=memread_in;
            memwrite_out<=memwrite_in; wb_sel_out<=wb_sel_in;
        end
    end
endmodule
