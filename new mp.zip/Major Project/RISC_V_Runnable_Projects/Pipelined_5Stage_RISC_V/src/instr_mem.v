// ============================================================
// Module : instr_mem.v
// Purpose: Read-Only Instruction Memory (256 words = 1 KB)
//          Pre-loaded with a 15-instruction test program
// BUG FIX: "integer i" moved from inside initial begin to module level
//           (Verilog-2001 does not allow variable declarations inside procedural blocks)
// ============================================================
module instr_mem (
    input  wire [31:0] addr,
    output wire [31:0] instr
);
    reg [31:0] mem [0:255];
    integer i;  // FIX: moved here from inside initial begin

    initial begin
        for (i = 0; i < 256; i = i + 1)
            mem[i] = 32'h0000_0013; // NOP

        mem[0]  = 32'h00A00093;   // addi x1,  x0, 10
        mem[1]  = 32'h01400113;   // addi x2,  x0, 20
        mem[2]  = 32'h002081B3;   // add  x3,  x1, x2     (EX→EX forward)
        mem[3]  = 32'h40208233;   // sub  x4,  x1, x2     (EX→EX forward)
        mem[4]  = 32'h0020F2B3;   // and  x5,  x1, x2
        mem[5]  = 32'h0020E333;   // or   x6,  x1, x2
        mem[6]  = 32'h0020C3B3;   // xor  x7,  x1, x2
        mem[7]  = 32'h00302023;   // sw   x3,  0(x0)
        mem[8]  = 32'h00002403;   // lw   x8,  0(x0)
        mem[9]  = 32'h00000013;   // nop  (load-use gap)
        mem[10] = 32'h003404B3;   // add  x9,  x8, x3     (MEM→EX forward)
        mem[11] = 32'h00318463;   // beq  x3,  x3, +8     (always taken)
        mem[12] = 32'h06300513;   // addi x10, x0, 99     (SKIPPED by branch flush)
        mem[13] = 32'h04D00593;   // addi x11, x0, 77     (branch target)
        mem[14] = 32'h00000063;   // beq  x0,  x0, 0      (halt)
    end

    assign instr = mem[addr[9:2]];
endmodule
