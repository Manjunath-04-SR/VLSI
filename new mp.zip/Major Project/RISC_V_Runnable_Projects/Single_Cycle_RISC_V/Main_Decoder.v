// Main Decoder
// BUG FIX 1: "(op =7'b1100011)" was single = (always evaluates true) → fixed to ==
// BUG FIX 2: RegWrite was missing I-type ALU (7'b0010011) — addi/andi/ori would NOT write
// BUG FIX 3: AluSrc was missing I-type ALU (7'b0010011) — addi/andi/ori would NOT use immediate
module Main_Decoder(op, zero, RegWrite, ResultSrc, MemWrite, AluSrc, PCSrc, ImmSrc, Aluop);
  input         zero;
  input  [6:0]  op;
  output        RegWrite, ResultSrc, MemWrite, AluSrc, PCSrc;
  output [1:0]  ImmSrc, Aluop;

  wire branch;

  // FIX: added 7'b0010011 (I-type ALU: ADDI, ANDI, ORI, XORI, SLTI, SLTIU)
  assign RegWrite = ((op == 7'b0000011) | (op == 7'b0110011) | (op == 7'b0010011)) ? 1'b1 : 1'b0;

  assign MemWrite = (op == 7'b0100011) ? 1'b1 : 1'b0;

  assign ResultSrc = (op == 7'b0000011) ? 1'b1 : 1'b0;

  // FIX: added 7'b0010011 (I-type ALU needs immediate, not register)
  assign AluSrc = ((op == 7'b0000011) | (op == 7'b0100011) | (op == 7'b0010011)) ? 1'b1 : 1'b0;

  // FIX: was "(op =7'b1100011)" — single = is assignment, not comparison; branch was ALWAYS 1
  assign branch = (op == 7'b1100011) ? 1'b1 : 1'b0;

  assign ImmSrc = (op == 7'b0100011) ? 2'b01 :
                  (op == 7'b1100011) ? 2'b10 : 2'b00;

  assign Aluop = (op == 7'b0110011) ? 2'b10 :
                 (op == 7'b0010011) ? 2'b10 :
                 (op == 7'b1100011) ? 2'b01 : 2'b00;

  assign PCSrc = zero & branch;
endmodule
