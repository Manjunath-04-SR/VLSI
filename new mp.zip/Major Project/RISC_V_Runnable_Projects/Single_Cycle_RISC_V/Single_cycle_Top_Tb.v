// Testbench — RISC-V Single-Cycle Processor
// BUG FIX: Removed `include "Single_cycle_Top.v" (causes duplicate errors in Vivado)
//          Add all source files individually in Vivado Sources panel.
//
// Test Program (matches pipelined test for direct comparison):
//   addi x1, x0, 10   → x1 = 10
//   addi x2, x0, 20   → x2 = 20
//   add  x3, x1, x2   → x3 = 30
//   sub  x4, x1, x2   → x4 = -10
//   and  x5, x1, x2   → x5 = 0
//   or   x6, x1, x2   → x6 = 30
//   nop                (spacer)
//
// SINGLE-CYCLE vs 5-STAGE PIPELINE COMPARISON:
//   Single-Cycle:  Each instruction takes exactly 1 clock cycle.
//                  The clock period must be long enough for the SLOWEST instruction
//                  (LW critical path: ~5 gate delays end-to-end).
//                  For N instructions: total time = N × T_slow
//
//   5-Stage Pipeline: After fill (5 cycles), one instruction completes per cycle.
//                  The clock period = only 1 stage delay (much shorter).
//                  For N instructions: total time ≈ (N + 4) × T_fast
//                  where T_fast ≈ T_slow / 5 (ideal)
//                  Throughput improvement ≈ 5× (minus hazard penalties)
//
//   LATENCY:       Single-cycle: 1 instruction = 1 long cycle
//                  Pipeline:     1 instruction = 5 short cycles (same total for 1 instr)
//                  Pipeline latency per instruction is HIGHER but THROUGHPUT is much better.
//
//   THROUGHPUT:    Single-cycle: 1 instr / T_slow
//                  Pipeline:     ~1 instr / T_fast ≈ 5 instr / T_slow  (5× better)
//
//   ENERGY:        Single-cycle activates all hardware every cycle (even unused stages).
//                  Pipeline divides work — each stage active for 1/5 of the instruction.
//                  Pipeline typically 30-50% more energy efficient per instruction at same freq.
//
//   ARCHITECTURE:  Single-cycle: simple, no pipeline registers, no hazard logic.
//                  Pipeline: requires 4 pipeline registers, forwarding unit, hazard unit,
//                  branch flush logic — approximately 2× the hardware area.
`timescale 1ns / 1ps

module Single_cycle_Top_Tb();
  reg clk = 1'b1;
  reg rst;

  Single_cycle_Top DUT(
    .clk(clk),
    .rst(rst)
  );

  always #50 clk = ~clk;  // 10 MHz clock (slow enough for single-cycle critical path)

  integer i;
  integer cycle_count;

  initial begin
    // ---- Load test program ----
    DUT.IM.Mem[0]  = 32'h00A00093; // addi x1, x0, 10
    DUT.IM.Mem[1]  = 32'h01400113; // addi x2, x0, 20
    DUT.IM.Mem[2]  = 32'h002081B3; // add  x3, x1, x2
    DUT.IM.Mem[3]  = 32'h40208233; // sub  x4, x1, x2
    DUT.IM.Mem[4]  = 32'h0020F2B3; // and  x5, x1, x2
    DUT.IM.Mem[5]  = 32'h0020E333; // or   x6, x1, x2
    DUT.IM.Mem[6]  = 32'h00000013; // nop  (halt)

    // Initialize registers to 0
    for (i = 0; i < 32; i = i + 1)
      DUT.RF.Registers[i] = 32'd0;

    cycle_count = 0;

    // ---- Reset sequence (active-low reset: rst=0 means reset) ----
    rst = 0;
    #150;
    rst = 1;
    $display("=== RESET RELEASED — Single-Cycle Simulation START ===");

    // ---- Run 8 cycles (1 cycle per instruction) ----
    repeat(8) begin
      @(posedge clk); #1;
      cycle_count = cycle_count + 1;
      $display("Cycle %0d | PC=0x%08h | Instr=0x%08h | rd=x%0d | ALU=%0d | RegWrite=%b",
        cycle_count, DUT.pc_top, DUT.RD_Instr,
        DUT.RD_Instr[11:7], $signed(DUT.ALU_Result), DUT.RegWrite);
    end

    $display("\n========== REGISTER FILE CHECK ==========");
    $display("x1 = %0d  (expected 10)  %s", $signed(DUT.RF.Registers[1]),
             (DUT.RF.Registers[1]==32'd10)?"PASS":"FAIL");
    $display("x2 = %0d  (expected 20)  %s", $signed(DUT.RF.Registers[2]),
             (DUT.RF.Registers[2]==32'd20)?"PASS":"FAIL");
    $display("x3 = %0d  (expected 30)  %s", $signed(DUT.RF.Registers[3]),
             (DUT.RF.Registers[3]==32'd30)?"PASS":"FAIL");
    $display("x4 = %0d (expected -10) %s", $signed(DUT.RF.Registers[4]),
             (DUT.RF.Registers[4]==32'hFFFFFFF6)?"PASS":"FAIL");
    $display("x5 = %0d  (expected 0)   %s", $signed(DUT.RF.Registers[5]),
             (DUT.RF.Registers[5]==32'd0)?"PASS":"FAIL");
    $display("x6 = %0d  (expected 30)  %s", $signed(DUT.RF.Registers[6]),
             (DUT.RF.Registers[6]==32'd30)?"PASS":"FAIL");

    $display("\n========== PERFORMANCE COMPARISON ==========");
    $display("Instructions executed      : 6");
    $display("Single-Cycle clock period  : 100 ns (10 MHz)");
    $display("Single-Cycle cycles taken  : 6");
    $display("Single-Cycle total time    : ~600 ns");
    $display("--- vs 5-Stage Pipeline ---");
    $display("Pipeline clock period      : 10 ns (100 MHz) — 10x faster clock");
    $display("Pipeline cycles for 6 inst : ~10 (6 instr + 4 fill + hazards)");
    $display("Pipeline total time        : ~100 ns");
    $display("Throughput improvement     : ~6x (pipeline at same gate count)");
    $display("=== Single-Cycle Simulation COMPLETE ===");
    $finish;
  end
endmodule
