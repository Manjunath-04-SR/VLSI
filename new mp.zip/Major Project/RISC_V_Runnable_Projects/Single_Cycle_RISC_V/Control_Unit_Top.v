// Control Unit Top
// BUG FIX 1: Added zero and PCSrc ports (Single_cycle_Top.v uses both)
// BUG FIX 2: Main_Decoder connections had wrong port names (.ALUSrc→.AluSrc, .ALUOp→.Aluop)
//            and zero was never passed → PCSrc was always 0 → branches never taken
// BUG FIX 3: ALU_Decoder connection .op(Op) passed 7-bit opcode to 1-bit op5 port
//            Fixed to .op5(Op[5]) — bit 5 distinguishes R-type from I-type for ADD vs SUB
// BUG FIX 4: funct7 port changed from [6:0] to 1-bit (only bit 30 = funct7[5] is needed)
module Control_Unit_Top(Op, zero, RegWrite, ImmSrc, ALUSrc, MemWrite,
                        ResultSrc, Branch, PCSrc, funct3, funct7, ALUControl);
  input  [6:0] Op;
  input        zero;        // FIX: added (was missing, PCSrc always 0 → branches broken)
  input  [2:0] funct3;
  input        funct7;      // FIX: 1-bit (bit 30 of instruction = funct7[5])

  output       RegWrite, ALUSrc, MemWrite, ResultSrc, Branch, PCSrc; // FIX: added PCSrc
  output [1:0] ImmSrc;
  output [2:0] ALUControl;

  wire [1:0] ALUOp;

  assign Branch = (Op == 7'b1100011) ? 1'b1 : 1'b0;

  Main_Decoder Main_Decoder(
    .op       (Op),
    .zero     (zero),        // FIX: was not connected
    .RegWrite (RegWrite),
    .ImmSrc   (ImmSrc),
    .MemWrite (MemWrite),
    .ResultSrc(ResultSrc),
    .AluSrc   (ALUSrc),      // FIX: was ".ALUSrc" but port name is "AluSrc"
    .Aluop    (ALUOp),       // FIX: was ".ALUOp" but port name is "Aluop"
    .PCSrc    (PCSrc)        // FIX: added — expose PCSrc to top module
  );

  alu_decoder ALU_Decoder(
    .AluOp     (ALUOp),
    .funct3    (funct3),
    .funct7    (funct7),
    .op5       (Op[5]),      // FIX: was ".op(Op)" — passing full 7-bit to 1-bit port
    .AluControl(ALUControl)
  );
endmodule
