// 32-bit ALU
module alu(a, b, cntrl, out, Z, N, V, C);
  input  [31:0] a, b;
  input  [2:0]  cntrl;
  output [31:0] out;
  output Z, N, V, C;

  wire [31:0] a_and_b = a & b;
  wire [31:0] a_or_b  = a | b;
  wire [31:0] not_b   = ~b;
  wire [31:0] mux2to1 = (cntrl[0] == 1'b0) ? b : not_b;
  wire [32:0] sum_ext = {1'b0, a} + {1'b0, mux2to1} + {32'b0, cntrl[0]};
  wire        cout    = sum_ext[32];
  wire [31:0] sum     = sum_ext[31:0];
  wire [31:0] slt     = {31'b0, sum[31]};
  wire [31:0] mux4to1 = (cntrl == 3'b000) ? sum     :
                        (cntrl == 3'b001) ? sum     :
                        (cntrl == 3'b010) ? a_and_b :
                        (cntrl == 3'b011) ? a_or_b  :
                        (cntrl == 3'b101) ? slt     : 32'h0;
  assign out = mux4to1;
  assign Z   = (out == 32'b0);
  assign N   = out[31];
  assign C   = cout & (~cntrl[1]);
  assign V   = (~cntrl[1]) & (a[31] ^ sum[31]) & (~(a[31] ^ b[31] ^ cntrl[0]));
endmodule
