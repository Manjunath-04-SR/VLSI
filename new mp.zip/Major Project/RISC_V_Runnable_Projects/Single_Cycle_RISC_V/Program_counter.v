// Program Counter — active-low reset
// BUG FIX: output must be declared as reg (driven by always block)
module _pc(pc_next, rst, clk, pc);
  input  [31:0] pc_next;
  input         rst, clk;
  output reg [31:0] pc;   // FIX: was "output [31:0] pc" (wire cannot be driven by always)

  always @(posedge clk) begin
    if (rst == 1'b0)
      pc <= 32'd0;
    else
      pc <= pc_next;
  end
endmodule
