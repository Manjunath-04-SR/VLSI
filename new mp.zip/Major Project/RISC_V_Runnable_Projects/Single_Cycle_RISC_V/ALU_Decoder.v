// ALU Decoder
// BUG FIX: port name was "AluOp" in port list but input declared as "ALUOp" — unified to AluOp
// BUG FIX: added default case to prevent synthesis latches
module alu_decoder(AluOp, op5, funct3, funct7, AluControl);
  input        op5;    // opcode bit 5 — distinguishes R-type from I-type
  input        funct7; // funct7 bit 5 (instruction bit 30) — distinguishes ADD/SUB
  input  [2:0] funct3;
  input  [1:0] AluOp;  // FIX: was declared as "ALUOp" (different from port name "AluOp")
  output [2:0] AluControl;

  wire [1:0] Concatenation = {op5, funct7};

  assign AluControl =
    (AluOp == 2'b00) ? 3'b000 :   // ADD (load/store)
    (AluOp == 2'b01) ? 3'b001 :   // SUB (branch)
    (AluOp == 2'b10 && funct3 == 3'b000 && Concatenation == 2'b11) ? 3'b001 : // SUB
    (AluOp == 2'b10 && funct3 == 3'b000) ? 3'b000 : // ADD / ADDI
    (AluOp == 2'b10 && funct3 == 3'b001) ? 3'b000 : // SLL (mapped to ADD as passthrough)
    (AluOp == 2'b10 && funct3 == 3'b010) ? 3'b101 : // SLT
    (AluOp == 2'b10 && funct3 == 3'b100) ? 3'b000 : // XOR (not in 3-bit ALU, map to ADD)
    (AluOp == 2'b10 && funct3 == 3'b110) ? 3'b011 : // OR
    (AluOp == 2'b10 && funct3 == 3'b111) ? 3'b010 : // AND
    3'b000; // default: ADD

endmodule
