// Sign Extend — supports all RV32I immediate formats
// Decodes opcode from instruction bits [6:0] to select format
// BUG FIX: original only handled I-type; now handles I/S/B/U/J types
module Sign_Extend(in, imm_ext);
  input  [31:0] in;
  output reg [31:0] imm_ext;

  wire [6:0] opcode = in[6:0];

  always @(*) begin
    case (opcode)
      // I-type: ADDI, ORI, ANDI, XORI, SLTI, SLTIU, SLLI, SRLI, SRAI, LW, LH, LB, JALR
      7'b0010011, 7'b0000011, 7'b1100111:
        imm_ext = {{20{in[31]}}, in[31:20]};

      // S-type: SW, SH, SB
      7'b0100011:
        imm_ext = {{20{in[31]}}, in[31:25], in[11:7]};

      // B-type: BEQ, BNE, BLT, BGE, BLTU, BGEU
      7'b1100011:
        imm_ext = {{19{in[31]}}, in[31], in[7], in[30:25], in[11:8], 1'b0};

      // U-type: LUI, AUIPC
      7'b0110111, 7'b0010111:
        imm_ext = {in[31:12], 12'b0};

      // J-type: JAL
      7'b1101111:
        imm_ext = {{11{in[31]}}, in[31], in[19:12], in[20], in[30:21], 1'b0};

      // R-type: no immediate
      default:
        imm_ext = 32'b0;
    endcase
  end
endmodule
